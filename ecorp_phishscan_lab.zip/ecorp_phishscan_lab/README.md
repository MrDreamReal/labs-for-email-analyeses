# ECorp PhishScan Lab — Synthetic Phishing Triage & DFIR Exercise

A fictional, safe training scenario for practicing static phishing-email analysis with **PhishScan**. It includes one synthetic `.eml`, incident communications, copy/paste CLI commands, and an analyst investigation checklist.

> **Safe-lab notice:** `ecorp.example`, other `.example` hosts, and TEST-NET IP addresses are placeholders. The message and attachments are constructed for static detection testing. Do not click URLs or execute/open attachments outside an isolated lab. No real credentials should be used.

## Contents

- `samples/ecorp_m365_verification_simulation.eml` — test email with spoofing/authentication clues, body/social-engineering signals, URL mismatch, Safe Links wrapper, QR code, tracking-image marker, and three harmless test attachments.
- `docs/SCENARIO_ECORP_IR_2026_1042.md` — full company scenario, helpdesk/SOC alert examples, reproduction-safe workflow, investigation checklist, and response notes.
- `RUN_COMMANDS.sh` — commands to analyze the sample and simulate the reported incident context.
- `reports/` — output location for generated PhishScan reports.

## Scenario

A fictional finance employee reports clicking a mailbox-verification link, downloading and opening an HTML attachment, and entering credentials. They deny approving an MFA prompt. Helpdesk (`helpdesk-max@ecorp.example`) escalates to SOC analyst (`soc-aziz@ecorp.example`) under case `ECORP-IR-2026-1042`.

The story is a simulation only. `--clicked`, `--creds`, `--executed`, and `--targeted` are analyst-supplied facts that alter triage context; they do not prove the events occurred. If the attachment was only downloaded and not opened, omit `--executed`.

## Prerequisites

- Python 3.8+
- PhishScan script placed at repository root as `phishscan.py`
- Optional: tools/libraries described by the script for deeper DNS, DKIM, archive, macro, and QR analysis

## Quick start

```bash
python3 phishscan.py --help

python3 phishscan.py samples/ecorp_m365_verification_simulation.eml \
  --out reports/ECORP-IR-2026-1042-baseline \
  --case ECORP-IR-2026-1042 \
  --analyst 'soc-aziz@ecorp.example' \
  --reported-by 'helpdesk-max@ecorp.example' \
  --status Open --verbose
```

## Simulate a reported credential exposure

```bash
python3 phishscan.py samples/ecorp_m365_verification_simulation.eml \
  --out reports/ECORP-IR-2026-1042-user-interaction \
  --case ECORP-IR-2026-1042 \
  --analyst 'soc-aziz@ecorp.example' \
  --reported-by 'helpdesk-max@ecorp.example' \
  --status Open --clicked --creds --executed --targeted --verbose
```

This specific example assumes the fictional user clicked the link, entered credentials, and opened the downloaded HTML attachment. Remove `--executed` if they only downloaded it; do not add `--mfa` because the scenario says MFA was not approved.

## Review outputs

By default, PhishScan writes Markdown, HTML, JSON, and an IOC CSV to the requested output directory. View `report.md` or `report.html` first, confirm each finding manually, then use `report.json` and `iocs.csv` for downstream workflows.

## Online checks

This sample uses reserved `.example` domains and TEST-NET addresses, so online reputation checks will not produce meaningful real-world results. The `--online` flag calls DNS/RDAP and may query VirusTotal/AbuseIPDB if API keys are configured. Use it only with authorized indicators, and consider privacy before submitting internal URLs or hashes to third parties.

## Defensive response workflow

1. Preserve the original email and record its SHA-256.
2. Search message telemetry for other recipients and message IDs.
3. Check URL-click, proxy, DNS, endpoint, and sign-in telemetry.
4. Verify whether the attachment was downloaded, opened, or executed.
5. If credentials were submitted, reset credentials and revoke sessions as appropriate; review MFA methods, OAuth consent, and inbox rules.
6. Quarantine/purge messages and block indicators only after confirming their validity and following organizational process.
7. Record verified facts separately from the reporter's unconfirmed claims.

## Ethical use

For authorized defensive analysis, incident-response training, or a lab environment you control. Do not use real targets, collect real passwords, execute suspicious files on production endpoints, or publish live credentials/tokens.

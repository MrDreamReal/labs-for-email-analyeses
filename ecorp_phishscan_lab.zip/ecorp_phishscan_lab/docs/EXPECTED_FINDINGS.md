# Expected Findings — ECorp PhishScan Lab

The local PhishScan v1.0.0 run on the provided `.eml` produced:

- **Verdict:** `MALICIOUS`
- **Score:** 59
- **Confidence:** `HIGH`
- **Base severity:** `LOW` (static baseline; no incident context flags)
- **Attachment count:** 5 parser records (including nested ZIP content)
- **IOC count:** 44
- **Observed labels:** spoofed Microsoft display name/lookalike domain, Reply-To and Return-Path mismatch, SPF/DKIM/DMARC/CompAuth failure markers, suspicious Received chain and TEST-NET origin IP, urgency/credential/secrecy language, hidden body text, link-text/href mismatch, QR code, tracking pixel, HTML form, suspicious HTML/PDF/ZIP/LNK patterns.

When re-run with the fictional scenario flags `--clicked --creds --executed --targeted`, the same script output assigns **CRITICAL** severity because the script's severity logic treats a malicious verdict plus `--executed` as critical. This is a tool scoring behavior, not an independent risk determination.

## Interpretation caveats

- The `.example` hostnames and TEST-NET IPs are placeholders reserved for documentation/training. They are not real malicious infrastructure.
- The EML intentionally includes a visible URL that differs from its hyperlink destination.
- The HTML attachment includes a comment containing static detection marker strings (`atob`, `new Blob`, and `createObjectURL`) so the static pattern detector can be tested. There is no executable JavaScript payload in the attachment. The HTML form targets a reserved `.example` host and has no collection backend.
- The PDF contains a JavaScript marker and a URI marker for static parser testing, but no automatic open action is wired to the JavaScript object.
- The ZIP contains a deliberately truncated/non-runnable LNK-like fixture. Its encoded content decodes to a harmless `Write-Output` lab message; it does not download or execute a payload.
- The high score is expected because the sample intentionally aggregates many indicators. It must not be taken as a calibrated score for real incidents.
- Some findings are heuristic and may overstate risk. Always inspect the actual evidence and validate all conclusions.
- Do not use `--online` expecting real reputation results. Online mode could submit some indicators to third-party services, and the sample's reserved domains have no meaningful reputation data.

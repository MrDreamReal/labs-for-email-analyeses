# ECorp Incident Simulation: Credential Phishing + Suspicious Attachments

**Case ID:** `ECORP-IR-2026-1042`  
**Severity at intake:** High (reported credential submission; validate)  
**Status:** Open — investigation in progress  
**Organization:** ECorp Services (fictional lab)  
**Domain convention:** All infrastructure uses reserved `.example` domains and TEST-NET IPs. Do not replace these with a real company's domain unless you own it or have written authorization.

## Executive summary

At 06:52 UTC on 17 October 2026, finance employee `nina.rahman@ecorp.example` reports receiving an email that impersonates Microsoft 365/ECorp IT. The email claims the mailbox will be suspended within 24 hours and asks the recipient to verify the account. It includes a misleading login link, a QR code, and HTML/PDF/ZIP attachments.

The employee reports that they clicked the link, downloaded `Password_Update.html`, opened it, and typed their work email and password into the simulated form. They **do not** report approving an MFA prompt. The SOC must validate the timeline using email gateway, proxy, endpoint, and Entra sign-in logs. The domains in this exercise are reserved examples; the sample form has no credential-collection backend and sends no real data.

## Example user report to Helpdesk

**From:** `nina.rahman@ecorp.example`  
**To:** `helpdesk-max@ecorp.example`  
**Subject:** I clicked an ECorp mailbox verification email

> Hi Helpdesk, I received a message titled “RE: Action required: ECorp mailbox verification expires within 24 hours”. It said my mailbox would be suspended. I clicked the verification link, downloaded `Password_Update.html`, opened it, and entered my work email and password. I realized it might be fake. I did not approve an MFA request. Can you escalate this to SOC?

## Helpdesk escalation to SOC

**From:** `helpdesk-max@ecorp.example`  
**To:** `soc-aziz@ecorp.example`  
**Subject:** High-priority phishing report — ECORP-IR-2026-1042

> SOC, please investigate case `ECORP-IR-2026-1042`. The reporting user says they clicked the URL, downloaded and opened an HTML attachment, and submitted credentials. MFA approval is denied/not reported. Preserve the original `.eml`, record its SHA-256, identify all recipients/clickers, investigate related sign-ins and mailbox changes, and advise on containment. Do not click the URLs or open attachments on a production workstation.

## Indicators embedded for static tool testing

- Sender display name claims `Microsoft 365 ECorp Security` but uses `no-reply@micros0ft-ecorp.example`.
- `Reply-To` and `Return-Path` differ from `From`.
- SPF, DKIM, DMARC, and CompAuth are represented as failures in synthetic headers.
- Received headers include documentation-only TEST-NET IP `203.0.113.45` and a fictional route.
- Subject uses `RE:` but the sample has no `In-Reply-To`/`References` thread context.
- Body contains urgency, authority, credential-request language, hidden text, mismatch between shown link and actual `href`, Safe Links wrapper, a QR code, a tiny tracking image, and a form.
- Attachments: `Password_Update.html` (static form and inert detection-marker comment), `Invoice_1042.pdf` (minimal parser fixture with JavaScript/URI markers but no automatic action), and `Benefits_Documents.zip` (contains a truncated/non-runnable `.lnk` test fixture and README).

**These are intentional lab indicators, not assertions about a real campaign.** Some detectors may flag inert comments or malformed file structures because they rely on static patterns. Validate every finding.

## Suggested command sequence

Run commands from the folder containing `phishscan.py`, or provide the correct path to it.

### 1. Static baseline: no user-interaction claims

```bash
python3 phishscan.py samples/ecorp_m365_verification_simulation.eml \
  --out reports/ECORP-IR-2026-1042-baseline \
  --case ECORP-IR-2026-1042 \
  --analyst 'soc-aziz@ecorp.example' \
  --reported-by 'helpdesk-max@ecorp.example' \
  --status Open --verbose
```

### 2. Scenario with reported interaction (use only because it is stated in this exercise)

```bash
python3 phishscan.py samples/ecorp_m365_verification_simulation.eml \
  --out reports/ECORP-IR-2026-1042-user-interaction \
  --case ECORP-IR-2026-1042 \
  --analyst 'soc-aziz@ecorp.example' \
  --reported-by 'helpdesk-max@ecorp.example' \
  --status Open --clicked --creds --executed --targeted --verbose
```

`--executed` is appropriate here because the fictional user says they opened the downloaded HTML attachment. If they only downloaded it and never opened it, **remove `--executed`**. Do not add `--mfa` because the user says they did not approve an MFA prompt.

### 3. Save attachments for static analysis

```bash
python3 phishscan.py samples/ecorp_m365_verification_simulation.eml \
  --out reports/ECORP-IR-2026-1042-attachments \
  --case ECORP-IR-2026-1042 --save-attachments --verbose
```

Inspect the saved files with static tools. Do not execute them. Note: `--save-attachments` writes attachment data into the output folder; it does not make them safe.

### 4. Select report outputs

```bash
python3 phishscan.py samples/ecorp_m365_verification_simulation.eml \
  --out reports/ECORP-IR-2026-1042-html \
  --format md,html,json --verbose
```

`report.md`, `report.html`, `report.json`, and `iocs.csv` should appear in the output directory. The JSON output helps with automation; Markdown/HTML are easier for analysts and case notes.

### 5. Hash the original email and inspect IOCs

```bash
sha256sum samples/ecorp_m365_verification_simulation.eml
column -s, -t < reports/ECORP-IR-2026-1042-baseline/iocs.csv | less -S
```

If `column` is unavailable, read `iocs.csv` in a text editor or spreadsheet.

## Analyst investigation checklist

1. Preserve the original message and calculate its SHA-256; keep a copy of full headers.
2. Use `EmailEvents` to search all recipients by message ID, sender, subject, and time.
3. Use `UrlClickEvents` to find recipients who clicked; verify if Safe Links recorded a block or click-through.
4. Search proxy/DNS logs for the destination host and correlate times with the user report.
5. Check endpoint telemetry for file creation/open events and any child processes after the reported download/open. Do not infer execution merely from download.
6. Review Entra `SigninLogs` for the user's sign-ins after credential submission: unfamiliar IP/device, unusual app, failures followed by success, or MFA anomalies.
7. Review audit logs for new authentication methods, OAuth consent, mailbox forwarding, and inbox-rule changes.
8. Search other mailboxes for the same `NetworkMessageId`, URLs, subjects, sender, and attachment hashes.
9. If credential exposure is substantiated: reset credentials, revoke sessions/tokens as appropriate, review MFA methods, and monitor for mailbox persistence. Coordinate with identity/security owners.
10. Quarantine/purge the email and block indicators only after confirming policy and scope. The `.example` indicators are reserved and should not be treated as real threat intel.
11. Record what is proven, what is only reported, and what is not yet verified.

## What not to do

- Do not click the links, scan the QR with a personal phone, submit real credentials, or open attachments on a normal workstation.
- Do not use `--online` for this sample expecting meaningful reputation results: `.example` domains and TEST-NET IPs are documentation placeholders. The online mode would submit indicators to third-party services and may disclose investigation data.
- Do not claim a user clicked, entered credentials, approved MFA, or executed a file unless the user report or telemetry supports it. Flags change triage severity/response guidance; they are not proof.
- Do not publicly upload real user emails or active tokens to GitHub.

## Expected tool behavior

The PhishScan report should call out multiple kinds of static indicators: mismatched sender/reply domains, displayed-link vs actual-href differences, authentication failures, urgency and credential terms, QR/hidden-image/form markers, risky attachments, archive contents, and suspicious command strings embedded in the non-runnable LNK fixture. Exact findings depend on the script version and optional libraries. There may be false positives because some static strings are intentionally inert lab markers.

## Evidence and conclusion template

- **Case:** ECORP-IR-2026-1042
- **Reported by:** helpdesk-max@ecorp.example
- **Assigned analyst:** soc-aziz@ecorp.example
- **User interaction:** Clicked = reported; credentials submitted = reported; attachment opened = reported; MFA approved = no
- **Verified recipients / clicks / sign-ins:** Fill from actual logs
- **Verdict:** Fill after reviewing tool output and telemetry
- **Confidence:** High / Medium / Low with justification
- **Containment:** Record actions, approvals, timestamps, and validation results
- **Lessons learned:** Which controls blocked or failed, and what should change

---

**Lab license/safety note:** This is a fictional, synthetic defensive training artifact. Use only in a lab you control or under explicit authorization.

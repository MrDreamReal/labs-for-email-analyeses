# PHISHING EMAIL ANALYSIS REPORT - ECORP-IR-2026-1042

**Verdict: MALICIOUS** | Score 59 | Severity LOW | Confidence HIGH

## 1. Case information

| Field | Value |
|---|---|
| Case ID | ECORP-IR-2026-1042 |
| Report generated | 2026-10-17 06:47:32 UTC |
| Analyst | soc-aziz@ecorp.example |
| Reported by | helpdesk-max@ecorp.example |
| Source file | ecorp_m365_verification_simulation.eml |
| SHA256 (.eml) | 4220becf1ec183c3a3f121d5efb49b8c5e30db3fe370a4fe6216debbba749773 |
| MD5 (.eml) | fd3229aaef998b27095a3d38e9f76694 |
| Size | 7,797 bytes |
| Verdict | MALICIOUS |
| Risk score | 59 (confidence HIGH) |
| Incident severity | LOW |
| Classification | Malware delivery |
| User interaction | none reported |
| Status | Open |
| Tool | phishscan 1.0.0 (static analysis only) |

## 2. Executive summary

The e-mail with subject "RE: Action required: ECorp mailbox verification expires within 24 hours" from no-reply@micros0ft-ecorp.example (display name: Microsoft 365 ECorp Security) was analysed statically (no URL was visited, no file executed). Verdict: MALICIOUS (risk score 59, confidence HIGH). Classification: Malware delivery. Top indicators: Password_Update.html; Suspicious URL; Benefits_Documents.zip!Invoice.lnk; Benefits_Documents.zip!Invoice.lnk; HTML <form> embedded in e-mail body. The message contains 10 URL(s) and 5 attachment(s). No user interaction has been reported. Incident severity is rated LOW.

## 3. Verdict and risk scoring

VERDICT: MALICIOUS   |   Score 59   |   Confidence HIGH   |   Thresholds: >=16 malicious, >=8 suspicious, >=3 low-risk

| Category | Raw points | Cap | Counted |
|---|---|---|---|
| Header | 20 | 10 | 10 |
| Authentication | 10 | 12 | 10 |
| Body | 22 | 12 | 12 |
| URL | 5 | 15 | 5 |
| Attachment | 40 | 22 | 22 |
| Intel | 0 | 25 | 0 |
| TOTAL |  |  | 59 |

## 4. Findings (sorted by weight)

| Severity | Category | Finding | Detail | Pts |
|---|---|---|---|---|
| HIGH | Attachment | Password_Update.html: HTML SMUGGLING pattern (Blob + atob/Uint8Array + download trigger) |  | 6 |
| HIGH | Attachment | Benefits_Documents.zip!Invoice.lnk: Risky file type .lnk: Executable/script |  | 5 |
| HIGH | Attachment | Benefits_Documents.zip!Invoice.lnk: Suspicious content: PowerShell encoded command |  | 5 |
| MEDIUM | URL | Suspicious URL: hxxps://login[.]microsoftonline[.]com[.]verify-ecorp[.]example/auth?case=ECORP-IR-2026-1042 | Brand 'Microsoft' in SUBDOMAIN but registered domain is verify-ecorp.example; Credential-themed keywords in path/query | 5 |
| HIGH | Body | HTML <form> embedded in e-mail body | actions: ['https://credential-collector.example/submit']; password field: True | 4 |
| HIGH | Attachment | Benefits_Documents.zip: Archive contains risky file(s): Invoice.lnk |  | 4 |
| HIGH | Header | Display name impersonates Microsoft | Display name 'Microsoft 365 ECorp Security' but sender domain is micros0ft-ecorp.example | 3 |
| HIGH | Header | Sender domain is a lookalike of a known brand | homoglyph/leet: 'micros0ft-ecorp.example' imitates Microsoft ('microsoft') | 3 |
| HIGH | Header | Mail gateway already flagged as phish/malware/spoof | X-Forefront-Antispam-Report CAT:PHSH | 3 |
| HIGH | Authentication | DMARC FAIL | policy p=reject | 3 |
| HIGH | Authentication | SPF FAIL | envelope domain: bulk-mail.example | 3 |
| HIGH | Body | Link text shows one domain but href goes to another | text: hxxps://login[.]microsoftonline[.]com/verify  ->  href: hxxps://login[.]microsoftonline[.]com[.]verify-ecorp[.]example/auth?case=ECORP-IR-2026-1042 | 3 |
| HIGH | Body | QR code decoded from image (quishing) | inline:<ecorp-lab-qr>: hxxps://verify-ecorp[.]example/lab/ECORP-IR-2026-1042 | 3 |
| HIGH | Attachment | Benefits_Documents.zip!Invoice.lnk: LNK shortcut file - commonly launches cmd/PowerShell |  | 3 |
| MEDIUM | Attachment | Password_Update.html: Password input field |  | 3 |
| MEDIUM | Attachment | Password_Update.html: Form posts to external URL |  | 3 |
| MEDIUM | Attachment | Invoice_1042.pdf: PDF contains JavaScript |  | 3 |
| MEDIUM | Attachment | Benefits_Documents.zip!Invoice.lnk: Suspicious content: PowerShell hidden window |  | 3 |
| HIGH | Header | Reply-To differs from From | From: no-reply@micros0ft-ecorp.example / Reply-To: helpdesk-case@external-mail.example | 2 |
| HIGH | Authentication | Microsoft composite authentication (compauth) FAIL |  | 2 |
| HIGH | Body | Secrecy / pressure phrases typical of BEC | confidential, do not call, keep this between us | 2 |
| MEDIUM | Header | Bulk / script mailer used | X-Mailer: PHPMailer lab fixture | 2 |
| MEDIUM | Header | Fake reply/forward subject (RE:/FW:) with no In-Reply-To/References | Subject: RE: Action required: ECorp mailbox verification expires within 24 hours | 2 |
| MEDIUM | Header | HELO name does not match reverse DNS of connecting IP | Hop #2: HELO=relay-bulk.example, rDNS=unknown, IP=203.0.113.45 | 2 |
| MEDIUM | Authentication | DKIM FAIL | Signature invalid (tampered, or modified by forwarder/list). | 2 |
| MEDIUM | Body | Heavy urgency / threat language | action required, expires, failure to, final notice, immediately, security alert, suspended, unusual activity | 2 |
| MEDIUM | Body | Credential / account-verification language | credentials, login, password, verify your account | 2 |
| MEDIUM | Body | Mentions scanning a QR code (quishing pattern) |  | 2 |
| MEDIUM | Attachment | Password_Update.html: Blob download trigger |  | 2 |
| LOW | Attachment | Password_Update.html: Risky file type .html: HTML/SVG (smuggling/credential-harvest risk) |  | 2 |
| MEDIUM | Body | Financial / payment language | bank details, invoice, payment | 1 |
| LOW | Header | Return-Path domain differs from From domain | Envelope sender bounce@bulk-mail.example vs From no-reply@micros0ft-ecorp.example (normal for ESPs, suspicious otherwise) | 1 |
| LOW | Header | Message-ID domain differs from sender domain | Message-ID <ecorp-ir-1042@relay-bulk.example> | 1 |
| LOW | Header | Recipient hidden (BCC / undisclosed) | Typical for mass mailing. | 1 |
| LOW | Body | Generic greeting | Dear user | 1 |
| LOW | Body | Hidden text/elements in HTML (display:none, font-size:0, ...) | 1 element(s) - used for filter evasion or preheader text | 1 |
| LOW | Body | Tracking pixel / web beacon | hxxps://track-ecorp[.]example/open/pixel[.]gif | 1 |
| LOW | Attachment | Benefits_Documents.zip: Risky file type .zip: Archive container |  | 1 |

## 5. E-mail details

| Field | Value |
|---|---|
| Subject | RE: Action required: ECorp mailbox verification expires within 24 hours |
| From (display) | Microsoft 365 ECorp Security |
| From (address) | no-reply@micros0ft-ecorp.example |
| Reply-To | helpdesk-case@external-mail.example |
| Return-Path | <bounce@bulk-mail.example> |
| To / Cc | - |
| Date | Sat, 17 Oct 2026 06:40:00 +0000 |
| Message-ID | <ecorp-ir-1042@relay-bulk.example> |
| X-Mailer / User-Agent | PHPMailer lab fixture |
| MIME parts | 1 text, 1 html, 3 attachment(s), 1 inline image(s) |

## 6. Header analysis

| Field | Value |
|---|---|
| Origin IP (bottom-most public hop) | 203[.]0[.]113[.]45 |
| Reverse DNS of origin | (run --online) |
| Received hops | 3 |

| # | From (HELO) | By | IPs | Timestamp (UTC) |
|---|---|---|---|---|
| 1 | mx.ecorp.example | inbox.ecorp.example | 192[.]0[.]2[.]20 | 2026-10-17 06:40:16 UTC |
| 2 | relay-bulk.example | mx.ecorp.example | 203[.]0[.]113[.]45 | 2026-10-17 06:40:12 UTC |
| 3 | localhost | relay-bulk.example | 127[.]0[.]0[.]1 | 2026-10-17 06:40:05 UTC |

Read the chain bottom-to-top: the BOTTOM hop is closest to the sender. Hop #1 is your own gateway.

- [HIGH] Display name impersonates Microsoft - Display name 'Microsoft 365 ECorp Security' but sender domain is micros0ft-ecorp.example
- [HIGH] Sender domain is a lookalike of a known brand - homoglyph/leet: 'micros0ft-ecorp.example' imitates Microsoft ('microsoft')
- [HIGH] Reply-To differs from From - From: no-reply@micros0ft-ecorp.example / Reply-To: helpdesk-case@external-mail.example
- [LOW] Return-Path domain differs from From domain - Envelope sender bounce@bulk-mail.example vs From no-reply@micros0ft-ecorp.example (normal for ESPs, suspicious otherwise)
- [LOW] Message-ID domain differs from sender domain - Message-ID <ecorp-ir-1042@relay-bulk.example>
- [MEDIUM] Bulk / script mailer used - X-Mailer: PHPMailer lab fixture
- [LOW] Recipient hidden (BCC / undisclosed) - Typical for mass mailing.
- [MEDIUM] Fake reply/forward subject (RE:/FW:) with no In-Reply-To/References - Subject: RE: Action required: ECorp mailbox verification expires within 24 hours
- [HIGH] Mail gateway already flagged as phish/malware/spoof - X-Forefront-Antispam-Report CAT:PHSH
- [MEDIUM] HELO name does not match reverse DNS of connecting IP - Hop #2: HELO=relay-bulk.example, rDNS=unknown, IP=203.0.113.45

| Field | Value |
|---|---|
| Forefront CAT | PHSH |
| Forefront SFV | NSPM |

## 7. Authentication analysis (SPF / DKIM / DMARC)

| Mechanism | Result | Domain / detail | Aligned with From? |
|---|---|---|---|
| SPF | fail | bulk-mail.example | no |
| DKIM | fail | bulk-mail.example | no |
| DMARC | fail | policy p=reject | - |
| ARC | n/a |  | - |
| CompAuth (MS) | fail |  | - |

- DMARC fail -> sender is not authorised for the visible From domain (spoof or attacker infrastructure).

Domain age not checked (run with --online, or manually: whois / rdap.org).

- [HIGH] DMARC FAIL - policy p=reject
- [HIGH] SPF FAIL - envelope domain: bulk-mail.example
- [MEDIUM] DKIM FAIL - Signature invalid (tampered, or modified by forwarder/list).
- [HIGH] Microsoft composite authentication (compauth) FAIL - 

## 8. Body analysis

| Field | Value |
|---|---|
| Urgency/threat terms | action required, expires, failure to, final notice, immediately, security alert, suspended, unusual activity, verify your, within 24 hours |
| Credential terms | credentials, login, password, verify your account |
| Financial terms | bank details, invoice, payment |
| Secrecy/BEC terms | confidential, do not call, keep this between us |
| Authority terms | helpdesk |
| Generic greeting | Dear user |
| Visible text length | 641 |

| Field | Value |
|---|---|
| links | 2 |
| forms | 1 |
| images | 2 |
| scripts | 0 |
| iframes | 0 |
| hidden | 1 |
| tracking pixels | 1 |
| meta refresh | 0 |

| Image | Decoded QR content (defanged) |
|---|---|
| inline:<ecorp-lab-qr> | hxxps://verify-ecorp[.]example/lab/ECORP-IR-2026-1042 |

- [MEDIUM] Heavy urgency / threat language - action required, expires, failure to, final notice, immediately, security alert, suspended, unusual activity
- [MEDIUM] Credential / account-verification language - credentials, login, password, verify your account
- [MEDIUM] Financial / payment language - bank details, invoice, payment
- [HIGH] Secrecy / pressure phrases typical of BEC - confidential, do not call, keep this between us
- [LOW] Generic greeting - Dear user
- [MEDIUM] Mentions scanning a QR code (quishing pattern) - 
- [LOW] Hidden text/elements in HTML (display:none, font-size:0, ...) - 1 element(s) - used for filter evasion or preheader text
- [HIGH] HTML <form> embedded in e-mail body - actions: ['https://credential-collector.example/submit']; password field: True
- [LOW] Tracking pixel / web beacon - hxxps://track-ecorp[.]example/open/pixel[.]gif
- [HIGH] Link text shows one domain but href goes to another - text: hxxps://login[.]microsoftonline[.]com/verify  ->  href: hxxps://login[.]microsoftonline[.]com[.]verify-ecorp[.]example/auth?case=ECORP-IR-2026-1042
- [HIGH] QR code decoded from image (quishing) - inline:<ecorp-lab-qr>: hxxps://verify-ecorp[.]example/lab/ECORP-IR-2026-1042

## 9. URL analysis (never click - defanged)

| URL (defanged) | Source | Score | Flags |
|---|---|---|---|
| hxxps://login[.]microsoftonline[.]com[.]verify-ecorp[.]example/auth?case=ECORP-IR-2026-1042 | HTML href | 5 | Brand 'Microsoft' in SUBDOMAIN but registered domain is verify-ecorp.example; Credential-themed keywords in path/query |
| hxxps://nam01[.]safelinks[.]protection[.]outlook[.]com/?url=https%3A%2F%2Fverify-ecorp[.]example%2Fportal%3Fcase%3DECORP-IR-2026-1042 | HTML href | 2 | Credential-themed keywords in path/query; Wrapped by Microsoft Defender Safe Links -> final: hxxps://verify-ecorp[.]example/portal?case=ECORP-IR-2026-1042 |
| hxxps://verify-ecorp[.]example/portal?redirect=https%3A%2F%2Ffiles-ecorp[.]example%2Fdoc | attachment: Password_Update.html | 2 | Wrapped by open-redirect parameter 'redirect' -> final: hxxps://files-ecorp[.]example/doc |
| hxxps://login[.]microsoftonline[.]com/verify | body text | 1 | Credential-themed keywords in path/query |
| hxxps://verify-ecorp[.]example/portal?case=ECORP-IR-2026-1042 | unwrapped from Microsoft Defender Safe L | 0 | - |
| hxxps://verify-ecorp[.]example/lab/ECORP-IR-2026-1042 | QR code (inline:<ecorp-lab-qr>) | 0 | - |
| hxxps://credential-collector[.]example/submit | attachment: Password_Update.html | 0 | - |
| hxxps://files-ecorp[.]example/doc | unwrapped from open-redirect parameter ' | 0 | - |
| hxxps://invoice-docs[.]example/view?id=ECORP-IR-2026-1042 | attachment: Invoice_1042.pdf | 0 | - |
| hxxps://verify-ecorp[.]example/lab/shortcut | attachment: Benefits_Documents.zip!Invoi | 0 | - |

Next manual steps: scan in urlscan.io (screenshot, redirects, form action / Telegram exfil), check VirusTotal/URLhaus/PhishTank, WHOIS age, crt.sh for sibling domains.

## 10. Attachment analysis

| Field | Value |
|---|---|
| File | Password_Update.html |
| True type | HTML document |
| Size / entropy | 849 B / 5.04 |
| SHA256 | 1b2091186aacca95c885756d6e3669209e400ab4c630ae7703ebf49ef0448bc5 |
| MD5 | 2fb5c8acf08ae15dafdd21bbfaf02133 |

- [LOW] Risky file type .html: HTML/SVG (smuggling/credential-harvest risk) (+2)
- [MEDIUM] Blob download trigger (+2)
- [MEDIUM] Password input field (+3)
- [MEDIUM] Form posts to external URL (+3)
- [HIGH] HTML SMUGGLING pattern (Blob + atob/Uint8Array + download trigger) (+6)
- Small local HTML page with a form: likely credential-harvesting page (opens locally, evades URL scanning)

- Embedded URL: hxxps://credential-collector[.]example/submit
- Embedded URL: hxxps://verify-ecorp[.]example/portal?redirect=https%3A%2F%2Ffiles-ecorp[.]example%2Fdoc

| Field | Value |
|---|---|
| File | Invoice_1042.pdf |
| True type | PDF document |
| Size / entropy | 390 B / 5.28 |
| SHA256 | e75eb923024494830ed0adc2e1bb9f0bbf8c7fe8149fc019f992ff6ef4984a17 |
| MD5 | 1113778cb34f3d31e723011b7ac95b91 |

- [MEDIUM] PDF contains JavaScript (+3)
- PDF keywords: /JavaScript=1, /JS=1, /URI=2
- 1 URI(s) embedded - PDF is probably a link lure

- Embedded URL: hxxps://invoice-docs[.]example/view?id=ECORP-IR-2026-1042

| Field | Value |
|---|---|
| File | Benefits_Documents.zip |
| True type | ZIP / OOXML container |
| Size / entropy | 643 B / 7.06 |
| SHA256 | a65b401a7415ca62bc20bd0668186510b651598fd86c09024e45908d715cacf1 |
| MD5 | dbb0c1441ab555a4d571eafb8f6e5ee2 |

- [LOW] Risky file type .zip: Archive container (+1)
- [HIGH] Archive contains risky file(s): Invoice.lnk (+4)

Contents: Invoice.lnk, README-LAB-ONLY.txt

| Field | Value |
|---|---|
| File | Benefits_Documents.zip!Invoice.lnk |
| True type | Windows shortcut (LNK) |
| Size / entropy | 704 B / 3.39 |
| SHA256 | 29d9d89029621a7c43b7abde7c0bab8e421a9ac027bf495f8dff1c49cdfb6063 |
| MD5 | 5b34c544eeba7e35e41186f49bed0c3c |

- [HIGH] Risky file type .lnk: Executable/script (+5)
- [HIGH] LNK shortcut file - commonly launches cmd/PowerShell (+3)
- [HIGH] Suspicious content: PowerShell encoded command (+5)
- [MEDIUM] Suspicious content: PowerShell hidden window (+3)

- Suspicious: PowerShell encoded command: powershell.exe -NoProfile -WindowStyle Hidden -EncodedCommand
- Suspicious: PowerShell hidden window: powershell.exe -NoProfile -WindowStyle Hidden

| Offset | Kind | Decoded preview |
|---|---|---|
| 86 | text | Write-Output "ECorp PhishScan lab fixture only; no network or system changes" |

- Embedded URL: hxxps://verify-ecorp[.]example/lab/shortcut

| Field | Value |
|---|---|
| File | Benefits_Documents.zip!README-LAB-ONLY.txt |
| True type | Text / script |
| Size / entropy | 82 B / 4.24 |
| SHA256 | 9cfd82d67562c897d29c7b2bf5a3b63648eadc93da5942275c49234d88953f8e |
| MD5 | 360c362737ea59d87887bdebf18b4e13 |

- No indicators.

## 11. Threat-intelligence enrichment

- Offline run: use --online with API keys, or the pivot links below.

## 12. Indicators of compromise (defanged)

| Type | Value | Context |
|---|---|---|
| email | bounce@bulk-mail[.]example | Return-Path (envelope sender) |
| email | helpdesk-case@external-mail[.]example | Reply-To (header) |
| email | no-reply@micros0ft-ecorp[.]example | From (header) |
| ip | 192[.]0[.]2[.]20 | Public IP in Received hop #1 |
| ip | 203[.]0[.]113[.]45 | X-Originating-IP |
| domain | bulk-mail[.]example | Return-Path domain |
| domain | credential-collector[.]example | URL host |
| domain | files-ecorp[.]example | URL host |
| domain | invoice-docs[.]example | URL host |
| domain | login[.]microsoftonline[.]com | URL host |
| domain | login[.]microsoftonline[.]com[.]verify-ecorp[.]example | URL host |
| domain | micros0ft-ecorp[.]example | Sender domain |
| domain | nam01[.]safelinks[.]protection[.]outlook[.]com | URL host |
| domain | track-ecorp[.]example | Remote image host |
| domain | verify-ecorp[.]example | URL host |
| url | hxxps://credential-collector[.]example/submit | URL (attachment: Password_Update.html) |
| url | hxxps://files-ecorp[.]example/doc | URL (unwrapped from open-redirect parameter 'redirect') |
| url | hxxps://invoice-docs[.]example/view?id=ECORP-IR-2026-1042 | URL (attachment: Invoice_1042.pdf) |
| url | hxxps://login[.]microsoftonline[.]com[.]verify-ecorp[.]example/auth?case=ECORP-IR-2026-1042 | URL (HTML href) |
| url | hxxps://login[.]microsoftonline[.]com/verify | URL (body text) |
| url | hxxps://nam01[.]safelinks[.]protection[.]outlook[.]com/?url=https%3A%2F%2Fverify-ecorp[.]example%2Fportal%3Fcase%3DECORP-IR-2026-1042 | URL (HTML href) |
| url | hxxps://track-ecorp[.]example/open/pixel[.]gif | Tracking pixel |
| url | hxxps://verify-ecorp[.]example/lab/ECORP-IR-2026-1042 | URL (QR code (inline:<ecorp-lab-qr>)) |
| url | hxxps://verify-ecorp[.]example/lab/shortcut | URL (attachment: Benefits_Documents.zip!Invoice.lnk) |
| url | hxxps://verify-ecorp[.]example/portal?case=ECORP-IR-2026-1042 | URL (unwrapped from Microsoft Defender Safe Links) |
| url | hxxps://verify-ecorp[.]example/portal?redirect=https%3A%2F%2Ffiles-ecorp[.]example%2Fdoc | URL (attachment: Password_Update.html) |
| sha256 | 1b2091186aacca95c885756d6e3669209e400ab4c630ae7703ebf49ef0448bc5 | Attachment Password_Update.html |
| sha256 | 29d9d89029621a7c43b7abde7c0bab8e421a9ac027bf495f8dff1c49cdfb6063 | Attachment Benefits_Documents.zip!Invoice.lnk |
| sha256 | 9cfd82d67562c897d29c7b2bf5a3b63648eadc93da5942275c49234d88953f8e | Attachment Benefits_Documents.zip!README-LAB-ONLY.txt |
| sha256 | a65b401a7415ca62bc20bd0668186510b651598fd86c09024e45908d715cacf1 | Attachment Benefits_Documents.zip |
| sha256 | e75eb923024494830ed0adc2e1bb9f0bbf8c7fe8149fc019f992ff6ef4984a17 | Attachment Invoice_1042.pdf |
| md5 | 1113778cb34f3d31e723011b7ac95b91 | Attachment Invoice_1042.pdf |
| md5 | 2fb5c8acf08ae15dafdd21bbfaf02133 | Attachment Password_Update.html |
| md5 | 360c362737ea59d87887bdebf18b4e13 | Attachment Benefits_Documents.zip!README-LAB-ONLY.txt |
| md5 | 5b34c544eeba7e35e41186f49bed0c3c | Attachment Benefits_Documents.zip!Invoice.lnk |
| md5 | dbb0c1441ab555a4d571eafb8f6e5ee2 | Attachment Benefits_Documents.zip |
| filename | Benefits_Documents.zip | Attachment name |
| filename | Invoice.lnk | Attachment name |
| filename | Invoice_1042.pdf | Attachment name |
| filename | Password_Update.html | Attachment name |
| filename | README-LAB-ONLY.txt | Attachment name |
| subject | RE: Action required: ECorp mailbox verification expires within 24 hours | Subject |
| message-id | <ecorp-ir-1042@relay-bulk.example> | Message-ID |
| mailer | PHPMailer lab fixture | X-Mailer/User-Agent |

Raw (non-defanged) IOCs for blocklists/SIEM ingestion are in iocs.csv - handle with care.

## 13. Scope and hunting queries

Run these to find other victims. Adjust time ranges and table names to your environment.

KQL - Who received it (EmailEvents)

```
EmailEvents
| where Timestamp > ago(30d)
| where SenderFromAddress in~ ("bounce@bulk-mail.example", "helpdesk-case@external-mail.example", "no-reply@micros0ft-ecorp.example") or Subject == "RE: Action required: ECorp mailbox verification expires within 24 hours" or SenderIPv4 in ("192.0.2.20", "203.0.113.45")
| project Timestamp, RecipientEmailAddress, SenderFromAddress, SenderMailFromAddress, SenderIPv4, Subject, DeliveryAction, DeliveryLocation, NetworkMessageId
| order by Timestamp asc
```

KQL - Emails containing the malicious domains (EmailUrlInfo)

```
EmailUrlInfo
| where Timestamp > ago(30d)
| where UrlDomain has_any ("micros0ft-ecorp.example", "outlook.com", "verify-ecorp.example")
| join kind=inner EmailEvents on NetworkMessageId
| project Timestamp, RecipientEmailAddress, SenderFromAddress, Url, UrlDomain, Subject, DeliveryLocation
```

KQL - Who clicked (UrlClickEvents)

```
UrlClickEvents
| where Timestamp > ago(30d)
| where Url has_any ("micros0ft-ecorp.example", "outlook.com", "verify-ecorp.example")
| project Timestamp, AccountUpn, Url, ActionType, IsClickedThrough, NetworkMessageId
| order by Timestamp asc
```

KQL - Endpoint/proxy connections to the domains (DeviceNetworkEvents)

```
DeviceNetworkEvents
| where Timestamp > ago(30d)
| where RemoteUrl has_any ("micros0ft-ecorp.example", "outlook.com", "verify-ecorp.example") or RemoteIP in ("192.0.2.20", "203.0.113.45")
| project Timestamp, DeviceName, InitiatingProcessAccountName, InitiatingProcessFileName, RemoteUrl, RemoteIP, RemotePort
```

KQL - Attachment delivered / executed

```
union
(EmailAttachmentInfo | where Timestamp > ago(30d) | where SHA256 in ("1b2091186aacca95c885756d6e3669209e400ab4c630ae7703ebf49ef0448bc5", "29d9d89029621a7c43b7abde7c0bab8e421a9ac027bf495f8dff1c49cdfb6063", "9cfd82d67562c897d29c7b2bf5a3b63648eadc93da5942275c49234d88953f8e", "a65b401a7415ca62bc20bd0668186510b651598fd86c09024e45908d715cacf1", "e75eb923024494830ed0adc2e1bb9f0bbf8c7fe8149fc019f992ff6ef4984a17") | project Timestamp, Source="Mail", Who=RecipientEmailAddress, FileName, SHA256),
(DeviceFileEvents | where Timestamp > ago(30d) | where SHA256 in ("1b2091186aacca95c885756d6e3669209e400ab4c630ae7703ebf49ef0448bc5", "29d9d89029621a7c43b7abde7c0bab8e421a9ac027bf495f8dff1c49cdfb6063", "9cfd82d67562c897d29c7b2bf5a3b63648eadc93da5942275c49234d88953f8e", "a65b401a7415ca62bc20bd0668186510b651598fd86c09024e45908d715cacf1", "e75eb923024494830ed0adc2e1bb9f0bbf8c7fe8149fc019f992ff6ef4984a17") | project Timestamp, Source="Endpoint", Who=DeviceName, FileName, SHA256)
| order by Timestamp asc
```

KQL - Sign-ins of exposed users (replace list)

```
let victims = dynamic(["victim1@company.com"]);
SigninLogs
| where TimeGenerated > ago(14d) and UserPrincipalName in~ (victims)
| project TimeGenerated, UserPrincipalName, IPAddress, Location, AppDisplayName, ClientAppUsed, ResultType,
          AuthenticationRequirement, ConditionalAccessStatus, DeviceDetail
| order by TimeGenerated desc
// look for: new country, impossible travel, legacy auth, "Device Code" flow, unfamiliar apps
```

KQL - Malicious inbox rules / forwarding

```
CloudAppEvents
| where Timestamp > ago(14d)
| where ActionType in ("New-InboxRule","Set-InboxRule","UpdateInboxRules","Set-Mailbox")
| extend Raw = tostring(RawEventData)
| where Raw has_any ("ForwardTo","RedirectTo","ForwardAsAttachmentTo","DeleteMessage","MoveToFolder","RSS","Archive")
| project Timestamp, AccountDisplayName, ActionType, Raw
```

KQL - New MFA method / OAuth consent

```
AuditLogs
| where TimeGenerated > ago(14d)
| where OperationName has_any ("security info","authentication method","Consent to application","Add OAuth2PermissionGrant","Add service principal")
| project TimeGenerated, OperationName, InitiatedBy, TargetResources, Result
```

Exchange / Purview containment commands

```
# Exchange Online / Purview: find then purge (review the preview count first!)
Connect-IPPSSession
New-ComplianceSearch -Name "ECORP-IR-2026-1042" -ExchangeLocation All -ContentMatchQuery 'from:"no-reply@micros0ft-ecorp.example" AND subject:"RE: Action required: ECorp mailbox verification expires within 24 hours"'
Start-ComplianceSearch -Identity "ECORP-IR-2026-1042"
# after reviewing results:
New-ComplianceSearchAction -SearchName "ECORP-IR-2026-1042" -Purge -PurgeType SoftDelete

# After credential exposure (per user):
Revoke-MgUserSignInSession -UserId victim@company.com
Get-InboxRule -Mailbox victim@company.com | fl Name,Enabled,ForwardTo,ForwardAsAttachmentTo,RedirectTo,DeleteMessage,MoveToFolder
Get-Mailbox victim@company.com | fl ForwardingAddress,ForwardingSmtpAddress,DeliverToMailboxAndForward
```

Splunk (generic) proxy/DNS/firewall hunt

```
index=proxy OR index=dns OR index=firewall earliest=-30d
(url_domain="micros0ft-ecorp.example" OR query="micros0ft-ecorp.example" OR url_domain="outlook.com" OR query="outlook.com" OR url_domain="verify-ecorp.example" OR query="verify-ecorp.example" OR dest_ip IN ("192.0.2.20","203.0.113.45"))
| stats count min(_time) as first max(_time) as last values(src) as sources by url_domain dest_ip
```

## 14. Response and containment plan

Always (verdict: MALICIOUS)

- [ ] Purge the message from ALL mailboxes (Threat Explorer / Content Search + purge)
- [ ] Block sender address, sender domain, URL domains and origin IP at gateway, proxy, DNS and firewall
- [ ] Add IOCs (see IOC section / iocs.csv) to SIEM, EDR custom indicators and threat-intel platform
- [ ] Search for other recipients, clickers and endpoint hits (queries in the Scope section)
- [ ] Report URL/domain for takedown (registrar, host, Google Safe Browsing, PhishTank, Microsoft)
- [ ] Notify the reporting user of the outcome; create/update detection rules

Payment / BEC angle

- [ ] Call Finance and the bank NOW if any payment was made or details changed (recall window is short)
- [ ] Verify requests out-of-band using a phone number from your directory, never from the e-mail
- [ ] Inform Legal / management; preserve evidence

## 15. Recommendations

Short term

- Block IOCs listed above; purge all copies; hunt other recipients.
- Check sign-ins and inbox rules for anyone who clicked; consider forcing re-authentication for exposed users.
- Submit the attachment to a sandbox and hunt hashes/C2 on endpoints; verify EDR coverage on recipients.

Long term

- Enforce DMARC p=quarantine/reject on your own domains; add external-sender banner.
- Phishing-resistant MFA (FIDO2/passkeys) + Conditional Access (compliant device, block legacy auth, block device-code flow if unused).
- Enable Safe Links / Safe Attachments, detonate attachments, block ISO/IMG/LNK/HTML-with-script/OneNote attachments where not needed.
- Block newly-registered domains (<30 days) and risky TLDs at proxy/DNS; QR-code scanning on gateway.
- Disable Office macros from the internet (Mark-of-the-Web); restrict external auto-forwarding.
- User awareness: easy 'Report phish' button, feedback to reporters, targeted training for finance/HR/executives.

## 16. MITRE ATT&CK mapping

| Technique | Name |
|---|---|
| T1027.006 | HTML Smuggling |
| T1056.003 | Input Capture: Web Portal Capture |
| T1059.001 | Command and Scripting: PowerShell |
| T1204.001 | User Execution: Malicious Link |
| T1204.002 | User Execution: Malicious File |
| T1566 | Phishing |
| T1566.001 | Phishing: Spearphishing Attachment |
| T1566.002 | Phishing: Spearphishing Link |
| T1583.001 | Acquire Infrastructure: Domains |
| T1598.003 | Phishing for Information: Spearphishing Link |
| T1656 | Impersonation |

## 17. Analyst checklist (auto-filled; MANUAL = still to do)

| Area | Check | Status | Note |
|---|---|---|---|
| Headers | From / Reply-To / Return-Path compared | DONE | Reply-To mismatch! |
| Headers | Display-name spoof / brand impersonation | FOUND |  |
| Headers | Received chain traced, origin IP identified | DONE | 203.0.113.45 |
| Headers | HELO/rDNS, timestamp & Date anomalies | FOUND |  |
| Headers | Mailer / bulk-sender fingerprint | FOUND | PHPMailer lab fixture |
| Auth | SPF result | FAIL | bulk-mail.example |
| Auth | DKIM result | FAIL | bulk-mail.example |
| Auth | DMARC result | FAIL | policy p=reject |
| Auth | Alignment with visible From | NOT ALIGNED |  |
| Auth | Sender domain age (WHOIS/RDAP) | RUN --online / manual | {} |
| Body | Urgency / threat / authority language | FOUND |  |
| Body | Credential / payment / secrecy request | FOUND |  |
| Body | Hidden text / forms / scripts / zero-width | FOUND |  |
| Body | Link text vs real href | MISMATCH |  |
| Body | QR codes | FOUND |  |
| URLs | All URLs extracted, defanged, analysed | DONE | 10 URL(s), 1 suspicious |
| URLs | Lookalike / punycode / shortener / abused platform | FOUND |  |
| URLs | Reputation + landing-page scan (urlscan / VT) | MANUAL | use pivots section |
| Attachments | True type vs extension, hashes | DONE |  |
| Attachments | Macros / scripts / smuggling / embedded objects | FOUND |  |
| Attachments | Sandbox detonation | MANUAL | submit hash/file to any.run / Joe / Hybrid Analysis if still unclear |
| Scope | Other recipients / clickers / endpoint hits | MANUAL | run hunting queries |
| Scope | Inbox rules, MFA changes, OAuth consent (if creds exposed) | n/a |  |
| Closure | Purge, block, IOCs added, user notified, report filed | MANUAL |  |

## 18. Timeline (fill in user-interaction and response times manually)

| Time (UTC) | Event |
|---|---|
| 2026-10-17 06:40:00 UTC | Message 'Date' header |
| 2026-10-17 06:40:05 UTC | Hop #3: localhost -> relay-bulk.example |
| 2026-10-17 06:40:12 UTC | Hop #2: relay-bulk.example -> mx.ecorp.example |
| 2026-10-17 06:40:16 UTC | Hop #1: mx.ecorp.example -> inbox.ecorp.example |
| 2026-10-17 06:47:32 UTC | Analysis performed by phishscan |

## 19. Manual pivots / next steps

Domain micros0ft-ecorp[.]example

- urlscan[.]io search : hxxps://urlscan[.]io/search/#domain%3Amicros0ft-ecorp.example
- crt.sh (sibling domains): hxxps://crt.sh/?q=%25.micros0ft-ecorp.example
- VirusTotal: hxxps://www.virustotal.com/gui/domain/micros0ft-ecorp.example
- WHOIS/RDAP: rdap.org/domain/micros0ft-ecorp.example
- Shodan/Censys: pivot on the hosting IP, favicon hash, and page title

Domain outlook[.]com

- urlscan[.]io search : hxxps://urlscan[.]io/search/#domain%3Aoutlook.com
- crt.sh (sibling domains): hxxps://crt.sh/?q=%25.outlook.com
- VirusTotal: hxxps://www.virustotal.com/gui/domain/outlook.com
- WHOIS/RDAP: rdap.org/domain/outlook.com
- Shodan/Censys: pivot on the hosting IP, favicon hash, and page title

Domain verify-ecorp[.]example

- urlscan[.]io search : hxxps://urlscan[.]io/search/#domain%3Averify-ecorp.example
- crt.sh (sibling domains): hxxps://crt.sh/?q=%25.verify-ecorp.example
- VirusTotal: hxxps://www.virustotal.com/gui/domain/verify-ecorp.example
- WHOIS/RDAP: rdap.org/domain/verify-ecorp.example
- Shodan/Censys: pivot on the hosting IP, favicon hash, and page title

Origin IP 203[.]0[.]113[.]45

- AbuseIPDB: abuseipdb[.]com/check/203.0.113.45
- Shodan: shodan[.]io/host/203.0.113.45
- VirusTotal: virustotal[.]com/gui/ip-address/203.0.113.45

Hash Password_Update.html

- VirusTotal: virustotal[.]com/gui/file/1b2091186aacca95c885756d6e3669209e400ab4c630ae7703ebf49ef0448bc5
- Hybrid Analysis / any.run / MalwareBazaar search by SHA256

Hash Invoice_1042.pdf

- VirusTotal: virustotal[.]com/gui/file/e75eb923024494830ed0adc2e1bb9f0bbf8c7fe8149fc019f992ff6ef4984a17
- Hybrid Analysis / any.run / MalwareBazaar search by SHA256

Hash Benefits_Documents.zip

- VirusTotal: virustotal[.]com/gui/file/a65b401a7415ca62bc20bd0668186510b651598fd86c09024e45908d715cacf1
- Hybrid Analysis / any.run / MalwareBazaar search by SHA256

Hash Benefits_Documents.zip!Invoice.lnk

- VirusTotal: virustotal[.]com/gui/file/29d9d89029621a7c43b7abde7c0bab8e421a9ac027bf495f8dff1c49cdfb6063
- Hybrid Analysis / any.run / MalwareBazaar search by SHA256

Hash Benefits_Documents.zip!README-LAB-ONLY.txt

- VirusTotal: virustotal[.]com/gui/file/9cfd82d67562c897d29c7b2bf5a3b63648eadc93da5942275c49234d88953f8e
- Hybrid Analysis / any.run / MalwareBazaar search by SHA256

## 20. Appendix: raw headers

```
Received: from mx.ecorp.example (mx.ecorp.example [192.0.2.20]) by
 inbox.ecorp.example with ESMTPS; Sat, 17 Oct 2026 06:40:16 +0000
Received: from relay-bulk.example (unknown [203.0.113.45]) by mx.ecorp.example
 with ESMTP; Sat, 17 Oct 2026 06:40:12 +0000
Received: from localhost (localhost [127.0.0.1]) by relay-bulk.example
 (Postfix) with ESMTP; Sat, 17 Oct 2026 06:40:05 +0000
Authentication-Results: mx.ecorp.example; spf=fail
 smtp.mailfrom=bounce@bulk-mail.example; dkim=fail header.d=bulk-mail.example;
 dmarc=fail (p=reject sp=reject) header.from=micros0ft-ecorp.example;
 compauth=fail reason=001
Received-SPF: Fail (sender IP is not authorized) identity=mailfrom;
 envelope-from="bounce@bulk-mail.example"; client-ip=203.0.113.45
X-Forefront-Antispam-Report: CIP:203.0.113.45;CTRY:ZZ;SFV:NSPM;CAT:PHSH;SCL:9
X-Originating-IP: [203.0.113.45]
Return-Path: <bounce@bulk-mail.example>
From: "Microsoft 365 ECorp Security" <no-reply@micros0ft-ecorp.example>
Reply-To: helpdesk-case@external-mail.example
To: undisclosed-recipients:;
Subject:
 RE: Action required: ECorp mailbox verification expires within 24 hours
Date: Sat, 17 Oct 2026 06:40:00 +0000
Message-ID: <ecorp-ir-1042@relay-bulk.example>
X-Mailer: PHPMailer lab fixture
MIME-Version: 1.0
Content-Type: multipart/mixed; boundary="===============8939871413689877170=="
```

## Sign-off

Prepared by: soc-aziz@ecorp.example    Reviewed by: ____________    Date: 2026-10-17

Automated static analysis aids but does not replace analyst judgement. Always validate with sandbox / threat-intel before closing.

# ECorp PhishScan Lab — commands (run from repository root)

# Check tool help
python3 phishscan.py --help

# 1. Static baseline (does not assert user clicked/entered credentials)
python3 phishscan.py samples/ecorp_m365_verification_simulation.eml \
  --out reports/ECORP-IR-2026-1042-baseline \
  --case ECORP-IR-2026-1042 \
  --analyst 'soc-aziz@ecorp.example' \
  --reported-by 'helpdesk-max@ecorp.example' \
  --status Open --verbose

# 2. Fictional scenario response: user clicked, entered creds, and opened HTML attachment
python3 phishscan.py samples/ecorp_m365_verification_simulation.eml \
  --out reports/ECORP-IR-2026-1042-user-interaction \
  --case ECORP-IR-2026-1042 \
  --analyst 'soc-aziz@ecorp.example' \
  --reported-by 'helpdesk-max@ecorp.example' \
  --status Open --clicked --creds --executed --targeted --verbose

# If the attachment was downloaded but NOT opened, remove --executed.
# Do not add --mfa unless the user approved an unexpected MFA request.

# 3. Save attachments as hashed .bin files for STATIC inspection only
python3 phishscan.py samples/ecorp_m365_verification_simulation.eml \
  --out reports/ECORP-IR-2026-1042-attachments \
  --case ECORP-IR-2026-1042 --save-attachments --verbose

# 4. Compute hash of original .eml
sha256sum samples/ecorp_m365_verification_simulation.eml

# 5. View generated IOC CSV
less reports/ECORP-IR-2026-1042-baseline/iocs.csv

# This sample uses reserved .example domains and TEST-NET IPs. Do not expect useful
# DNS/VT/AbuseIPDB results; avoid --online unless you deliberately want to submit those
# sample indicators to external services.
